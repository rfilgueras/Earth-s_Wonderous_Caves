﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VirtualEcosystemTwo.Items
{
    public class HerbalPotion : Item
    {
    }
}