﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VirtualEcosystemTwo.Pages
{
    /// <summary>
    /// Interaction logic for CraftPage.xaml
    /// </summary>
    public partial class CraftPage : Page
    {
        public CraftPage()
        {
            InitializeComponent();
            Set();
        }

        private void InventoryBtn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Pages/InventoryPage.xaml", UriKind.Relative));
        }

        private void MapBtn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Pages/MapPage.xaml", UriKind.Relative));
        }

        private void Set()
        {
            currentplayerTxt.Text = MainWindow.player.Name;
        }

        private void BasaltOne_Selected(object sender, RoutedEventArgs e)
        {
            firstResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/basalt.png", UriKind.Relative));
            currentQuantityOne.Text = $"{MainWindow.resources[4].Quantity} X";
        }

        private void CrystalOne_Selected(object sender, RoutedEventArgs e)
        {
            firstResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/crystal.png", UriKind.Relative));
            currentQuantityOne.Text = $"{MainWindow.resources[0].Quantity} X";
        }

        private void HoneyOne_Selected(object sender, RoutedEventArgs e)
        {
            firstResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/honey.png", UriKind.Relative));
            currentQuantityOne.Text = $"{MainWindow.resources[10].Quantity} X";
        }

        private void LeadOne_Selected(object sender, RoutedEventArgs e)
        {
            firstResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/lead.png", UriKind.Relative));
            currentQuantityOne.Text = $"{MainWindow.resources[2].Quantity} X";
        }

        private void LimestoneOne_Selected(object sender, RoutedEventArgs e)
        {
            firstResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/limestone.png", UriKind.Relative));
            currentQuantityOne.Text = $"{MainWindow.resources[5].Quantity} X";
        }

        private void StalactitesOne_Selected(object sender, RoutedEventArgs e)
        {
            firstResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/stalactites.png", UriKind.Relative));
            currentQuantityOne.Text = $"{MainWindow.resources[3].Quantity} X";
        }

        private void StalagmitesOne_Selected(object sender, RoutedEventArgs e)
        {
            firstResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/stalagmites.png", UriKind.Relative));
            currentQuantityOne.Text = $"{MainWindow.resources[1].Quantity} X";
        }

        private void WildGrassOne_Selected(object sender, RoutedEventArgs e)
        {
            firstResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/wildgrass.png", UriKind.Relative));
            currentQuantityOne.Text = $"{MainWindow.resources[8].Quantity} X";
        }

        private void CoolWaterOne_Selected(object sender, RoutedEventArgs e)
        {
            firstResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/coolwater.png", UriKind.Relative));
            currentQuantityOne.Text = $"{MainWindow.resources[9].Quantity} X";

        }

        private void SilkOne_Selected(object sender, RoutedEventArgs e)
        {
            firstResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/silk.png", UriKind.Relative));
            currentQuantityOne.Text = $"{MainWindow.resources[11].Quantity} X";
        }

        // List two
        private void BasaltTwo_Selected(object sender, RoutedEventArgs e)
        {
            secondResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/basalt.png", UriKind.Relative));
            currentQuantityTwo.Text = $"{MainWindow.resources[4].Quantity} X";
        }

        private void CrystalTwo_Selected(object sender, RoutedEventArgs e)
        {
            secondResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/crystal.png", UriKind.Relative));
            currentQuantityTwo.Text = $"{MainWindow.resources[0].Quantity} X";
        }

        private void HoneyTwo_Selected(object sender, RoutedEventArgs e)
        {
            secondResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/honey.png", UriKind.Relative));
            currentQuantityTwo.Text = $"{MainWindow.resources[10].Quantity} X";
        }

        private void LeadTwo_Selected(object sender, RoutedEventArgs e)
        {
            secondResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/lead.png", UriKind.Relative));
            currentQuantityTwo.Text = $"{MainWindow.resources[2].Quantity} X";
        }

        private void LimestoneTwo_Selected(object sender, RoutedEventArgs e)
        {
            secondResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/limestone.png", UriKind.Relative));
            currentQuantityTwo.Text = $"{MainWindow.resources[5].Quantity} X";
        }

        private void StalactitesTwo_Selected(object sender, RoutedEventArgs e)
        {
            secondResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/stalactites.png", UriKind.Relative));
            currentQuantityTwo.Text = $"{MainWindow.resources[3].Quantity} X";
        }

        private void StalagmitesTwo_Selected(object sender, RoutedEventArgs e)
        {
            secondResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/stalagmites.png", UriKind.Relative));
            currentQuantityTwo.Text = $"{MainWindow.resources[1].Quantity} X";
        }

        private void WildGrassTwo_Selected(object sender, RoutedEventArgs e)
        {
            secondResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/wildgrass.png", UriKind.Relative));
            currentQuantityTwo.Text = $"{MainWindow.resources[8].Quantity} X";
        }

        private void CoolWaterTwo_Selected(object sender, RoutedEventArgs e)
        {
            secondResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/coolwater.png", UriKind.Relative));
            currentQuantityTwo.Text = $"{MainWindow.resources[9].Quantity} X";
        }
        private void SilkTwo_Selected(object sender, RoutedEventArgs e)
        {
            secondResourceImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/silk.png", UriKind.Relative));
            currentQuantityTwo.Text = $"{MainWindow.resources[11].Quantity} X";
        }

        private Image SwitchImg(string imgName)
        {
            Image image = new Image();
            Image currentImg = image;
            currentImg.Source = new BitmapImage(new Uri($"/Graphics/ItemImg/{imgName}", UriKind.Relative));
            return currentImg;
        }
       
        //private void ChangeSelection(object sender, SelectionChangedEventArgs args)
        //{
        //    ListBoxItem lbi = ((sender as ListBox).SelectedItem as ListBoxItem);
        //    currentQuantityOne.Text = $"{lbi.Content.ToString()}";

        //}

        private void CraftBtn_Click(object sender, RoutedEventArgs e)
        {
            if (currentQuantityOne.Text != $"{0}" && currentQuantityTwo.Text != $"{0}")
            {
                if (MainWindow.player.CheckBrickIngredients(true))
                {
                    MainWindow.player.CraftBrick();
                    itemInfoTxt.Text = MainWindow.items[0].PrintItemInfo(MainWindow.items[0].Name);
                    craftedItem.Source = new BitmapImage(new Uri("/Graphics/ItemImg/bricks.png", UriKind.Relative)); 
                }
                else if (MainWindow.player.CheckRopeIngredients(true))
                {
                    MainWindow.player.CraftRope();
                    itemInfoTxt.Text = MainWindow.items[3].PrintItemInfo(MainWindow.items[3].Name);
                    craftedItem.Source = new BitmapImage(new Uri("/Graphics/ItemImg/rope.png", UriKind.Relative));
                    //craftedItem = SwitchImg("rope.png");
                }
                else if (MainWindow.player.CheckClothIngredients(true))
                {
                    MainWindow.player.CraftCloth();
                    itemInfoTxt.Text = MainWindow.items[4].PrintItemInfo(MainWindow.items[4].Name);
                    craftedItem.Source = new BitmapImage(new Uri("/Graphics/ItemImg/cloth.png", UriKind.Relative));
                    //craftedItem = SwitchImg("cloth.png");
                }
                else if (MainWindow.player.CheckShelterIngredients(true))
                {
                    MainWindow.player.CraftShelter();
                    itemInfoTxt.Text = MainWindow.items[6].PrintItemInfo(MainWindow.items[6].Name);
                    craftedItem.Source = new BitmapImage(new Uri("/Graphics/ItemImg/shelter.png", UriKind.Relative));
                }
                else if (MainWindow.player.CheckCoolingSuitIngredients(true))
                {
                    MainWindow.player.CraftShelter();
                    itemInfoTxt.Text = MainWindow.items[7].PrintItemInfo(MainWindow.items[7].Name);
                    craftedItem.Source = new BitmapImage(new Uri("/Graphics/ItemImg/suit.png", UriKind.Relative));
                }
                else
                {
                    craftedItem.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/mysteryResource.png", UriKind.Relative));
                }

                resultsLbl.Visibility = Visibility.Visible;
            }
        }

        private void ItemRecipeLbl_MouseEnter(object sender, MouseEventArgs e)
        {
            itemInfoTxt.Text = $"{MainWindow.items[0].PrintRecipe(MainWindow.items[0].Name)}\n{MainWindow.items[3].PrintRecipe(MainWindow.items[3].Name)}\n{MainWindow.items[4].PrintRecipe(MainWindow.items[4].Name)}\n{MainWindow.items[6].PrintRecipe(MainWindow.items[6].Name)}\n{MainWindow.items[7].PrintRecipe(MainWindow.items[7].Name)}";
        }

        private void ResourceListOne_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
