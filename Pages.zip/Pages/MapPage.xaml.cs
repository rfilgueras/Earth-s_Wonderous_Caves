﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VirtualEcosystemTwo.Pages
{
    /// <summary>
    /// Interaction logic for MapPage.xaml
    /// </summary>
    public partial class MapPage : Page
    {
        public MapPage()
        {
            InitializeComponent();
            Set();
        }
 
        private void Set()
        {
            welcomeLbl.Content = $"  >> Hello, {MainWindow.player.Name}! Where would you like to explore?";
        }
        private void BasaltCaveBtn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Pages/BasaltCavePage.xaml", UriKind.Relative));
        }

        private void GreatBlueHoleBtn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Pages/GreatBlueHolePage.xaml", UriKind.Relative));
        }

        private void WaitomoCaveBtn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Pages/WaitomoCavePage.xaml", UriKind.Relative));
        }

        private void CrystalCavesBtn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Pages/CrystalCavesPage.xaml", UriKind.Relative));
        }
    }
}
