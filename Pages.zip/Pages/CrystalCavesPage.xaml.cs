﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace VirtualEcosystemTwo.Pages
{
    /// <summary>
    /// Interaction logic for CrystalCavesPage.xaml
    /// </summary>
    public partial class CrystalCavesPage : Page
    {
        DispatcherTimer timer;
        DispatcherTimer deathTimer;
        TimeSpan timeSpan;
        TimeSpan deathSpan;

        public CrystalCavesPage()
        {
            InitializeComponent();
            Set();

        }


        // Navigation button to inventory page.
        private void InventoryBtn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Pages/InventoryPage.xaml", UriKind.Relative));
        }
        // Navigation button to map page.
        private void MapBtn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Pages/MapPage.xaml", UriKind.Relative));
        }
        // Navigation button to craft page.
        private void CraftBtn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Pages/CraftPage.xaml", UriKind.Relative));
        }

        private void Set()
        {
            currentplayerTxt.Text = MainWindow.player.Name;
            GameLoop();
            SetEnvironment();
            resourceTwoAmtTxt.Visibility = resourceThreeAmtTxt.Visibility = resourceOneAmtTxt.Visibility = HiddenResourceAmtTxt.Visibility = Visibility.Hidden;
            ResourceOneBtn.Visibility = ResourceTwoBtn.Visibility = ResourceThreeBtn.Visibility = HiddenResouceBtn.Visibility = Visibility.Hidden;
            MutualObligateOrganismImg.Visibility = Visibility.Hidden;

        }

        private void GameLoop()
        {
            MainWindow.game.NextDay();
            calendarLbl.Text = $"Month: {MainWindow.game.months[MainWindow.game.Month]}   Day: {MainWindow.game.Day}";
            DayCounter();
            DeathTimer();
        }
        private void DayCounter()
        {
            timeSpan = TimeSpan.FromSeconds(15);
            timer = new DispatcherTimer
                (
                new TimeSpan(0, 0, 1),
                DispatcherPriority.Normal,
                delegate
                {
                    timeCounterTxt.Text = deathSpan.ToString("c");
                    if (timeSpan == TimeSpan.Zero)
                    {
                        timer.Stop();
                        MainWindow.game.NextDay();
                    }
                    timeSpan = timeSpan.Add(TimeSpan.FromSeconds(-1));
                },
                Application.Current.Dispatcher
                );
            timer.Start();
        }
        private void DeathTimer()
        {
            deathSpan = TimeSpan.FromSeconds(15);
            deathTimer = new DispatcherTimer
                (
                new TimeSpan(0, 0, 1),
                DispatcherPriority.Normal,
                delegate
                {
                    counterTxt.Text = deathSpan.ToString("c");
                    if (deathSpan == TimeSpan.Zero)
                    {
                       deathTimer.Stop();
                        life1.Visibility = Visibility.Hidden;
                    }

                    if (deathSpan == TimeSpan.FromSeconds(10))
                    {
                        life3.Visibility = Visibility.Hidden;
                    }

                    if (deathSpan == TimeSpan.FromSeconds(6))
                    {
                        life2.Visibility = Visibility.Hidden;
                    }

                    if (MainWindow.currentEnvironment.InitialTemp == MainWindow.currentEnvironment.IdealTemp)
                    {
                        deathTimer.Stop();
                        counterTxt.Visibility = Visibility.Hidden;
                        MainWindow.currentEnvironment.IdealTempCheck(true);
                    }

                    deathSpan = deathSpan.Add(TimeSpan.FromSeconds(-1));
                },
                Application.Current.Dispatcher
                );
            deathTimer.Start();
        }
        private void SetEnvironment()
        {
            MainWindow.currentEnvironment = MainWindow.environments[0];
            MainWindow.currentEnvironment.Name = MainWindow.environments[0].Name;
            MainWindow.currentEnvironment.InitialTemp = MainWindow.environments[0].InitialTemp;
            MainWindow.currentEnvironment.IdealTemp = MainWindow.environments[0].IdealTemp;
            tempLbl.Content = $"{ MainWindow.environments[0].InitialTemp} F";
            CurrentEnvironmentTxt.Text = MainWindow.currentEnvironment.Name;
            TriggerEvent();

            //Resources
            
            MainWindow.resources[6].ResourceAmount = MainWindow.currentResource.SetRandomSpawn();
            MainWindow.resources[3].ResourceAmount = MainWindow.currentResource.SetRandomSpawn();
            MainWindow.resources[0].ResourceAmount = MainWindow.currentResource.SetRandomSpawn();
            MainWindow.resources[10].ResourceAmount = MainWindow.currentResource.SetRandomSpawn();

            resourceOneAmtTxt.Text = $"{MainWindow.resources[6].ResourceAmount}";
            resourceTwoAmtTxt.Text = $"{MainWindow.resources[6].ResourceAmount}";
            resourceThreeAmtTxt.Text = $"{MainWindow.resources[3].ResourceAmount}";
            HiddenResourceAmtTxt.Text = $"{MainWindow.resources[10].ResourceAmount}";

        }
        private void TriggerEvent()
        {

            //mssgTxt.Text = MainWindow.currentEnvironment.TempStatusMssg(MainWindow.currentEnvironment.Name);
            if (MainWindow.currentEnvironment.InitialTemp < MainWindow.currentEnvironment.IdealTemp)
            {
                MainWindow.currentEvent.Name = "Lower Temp";
                eventImg.Source = new BitmapImage(new Uri("/Graphics/Overlays/lowTemp.png", UriKind.Relative));
                mssgTxt.Text = $"Brrr!\n {MainWindow.player.Name}, it's too cold for the organism that lives here. Quickly! adjust the temperature to save it before the timer runs out!";
            }

            else if (MainWindow.currentEnvironment.InitialTemp > MainWindow.currentEnvironment.IdealTemp)
            {
                MainWindow.currentEvent.Name = "High Temp";
                eventImg.Source = new BitmapImage(new Uri("/Graphics/Overlays/highTemp.png", UriKind.Relative));
                mssgTxt.Text = $"Uggh It feels like my flashlight is melting!\n{MainWindow.player.Name}, it's too hot for the organism that lives here.  Quickly! adjust the temperature to save it before the timer runs out!";
            }

            else if (MainWindow.resources[0].ResourceAmount == 0 && MainWindow.resources[5].ResourceAmount == 0 && MainWindow.resources[3].ResourceAmount ==0)
            {
                MainWindow.currentEvent.Name = "Mine Collapse";
                eventImg.Source = new BitmapImage(new Uri("/Graphics/Overlays/CaveCollapse.png", UriKind.Relative));
                mssgTxt.Text = $"Oh No! the cave is collapsing! You collected too many of it's resources!";
            }
            else if (MainWindow.organisms[12].IsAlive == false)
            {
                eventImg.Source = new BitmapImage(new Uri("/Graphics/Overlays/playerDeathOverlay.png", UriKind.Relative));
                mssgTxt.Text = $"The organism died!";
                MainWindow.game.GameOver();
            }

            else
            {
                eventImg.Source = null;
                mssgTxt.Text = $"Perfect weather we're having today {MainWindow.player.Name}! You can now freely explore";
            }

        }
        private void ExploreBtn_Click(object sender, RoutedEventArgs e)
        {
            mssgTxt.Text = MainWindow.currentEnvironment.PrintEnvironmentInfo(MainWindow.currentEnvironment.Name);
            resourceTwoAmtTxt.Visibility = resourceThreeAmtTxt.Visibility = resourceOneAmtTxt.Visibility = Visibility.Visible;
            ResourceOneBtn.Visibility = ResourceTwoBtn.Visibility = ResourceThreeBtn.Visibility = Visibility.Visible;
            MutualObligateOrganismImg.Visibility = Visibility.Visible;

            mssgTxt.Text = "You found some resources and another organism!";
        }

        private void RaiseTempBtn_Click(object sender, RoutedEventArgs e)
        {
            //int tempAmount = MainWindow.currentEnvironment.InitialTemp;
            try
            {
                //Check if environment is equal to ideal temp
                if (MainWindow.currentEnvironment.InitialTemp >= MainWindow.currentEnvironment.IdealTemp)
                {
                    // increase temp by one
                    MainWindow.currentEnvironment.InitialTemp++;
                    tempLbl.Content = $"{MainWindow.currentEnvironment.InitialTemp -1} F";
                }
                else
                {
                    RaiseTempBtn.Visibility = Visibility.Hidden;
                    eventImg.Source = null;
                }

            }
            catch (Exception)
            {
                MessageBox.Show("This button doesn't work right lmao");
                throw;
            }
            
            
        }

        private void LowerTempBtn_Click(object sender, RoutedEventArgs e)
        {
            int tempAmount = MainWindow.currentEnvironment.InitialTemp;
            try
            {
                if (tempAmount == MainWindow.currentEnvironment.IdealTemp)
                {
                    eventImg.Source = null;                 
                }
                else
                {
                    tempAmount--;
                    tempLbl.Content = $"{MainWindow.currentEnvironment.InitialTemp -1} F";
                    MainWindow.currentEnvironment.InitialTemp = tempAmount;

                }
            }
            catch (Exception)
            {
                MessageBox.Show("Something went horribly wrong lmao");
                throw;
            }
            
        }

        private void ResourceOneBtn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow.resources[0].ResourceAmount--;
            //MainWindow.resources[0].Quantity++;
            MainWindow.resources[0].AddQuantity(MainWindow.resources[0].Name);
            resourceOneAmtTxt.Text = $"{MainWindow.resources[0].ResourceAmount}";
            mssgTxt.Text = MainWindow.resources[0].PrintResourceInfo(MainWindow.resources[0].Name);
            if (MainWindow.resources[0].ResourceAmount == 0)
            {
                ResourceOneBtn.Visibility = Visibility.Hidden;
                resourceOneAmtTxt.Visibility = Visibility.Hidden;
                mssgTxt.Text = $"You've there aren't any {MainWindow.resources[0].Name} left to collect.";
            }
        }

        private void ResourceTwoBtn_Click(object sender, RoutedEventArgs e)
        {
            // Collect resource
            MainWindow.resources[5].ResourceAmount--;
            MainWindow.resources[5].Quantity++;
            MainWindow.resources[5].AddQuantity(MainWindow.resources[5].Name);
            resourceTwoAmtTxt.Text = $"{MainWindow.resources[5].ResourceAmount}";
            mssgTxt.Text = MainWindow.resources[5].PrintResourceInfo(MainWindow.resources[5].Name);
            if (MainWindow.resources[5].ResourceAmount == 0)
            {
                ResourceTwoBtn.Visibility = Visibility.Hidden;
                resourceTwoAmtTxt.Visibility = Visibility.Hidden;
                mssgTxt.Text = $"You've there aren't any {MainWindow.resources[5].Name} left to collect.";
            }
        }

        private void ResourceThreeBtn_Click(object sender, RoutedEventArgs e)
        {
            // Collect resource
            MainWindow.resources[3].ResourceAmount--;
            //MainWindow.resources[3].Quantity++;
            MainWindow.resources[3].AddQuantity(MainWindow.resources[3].Name);
            resourceThreeAmtTxt.Text = $"{MainWindow.resources[3].ResourceAmount}";
            mssgTxt.Text = MainWindow.resources[3].PrintResourceInfo(MainWindow.resources[3].Name);
            if (MainWindow.resources[3].ResourceAmount == 0)
            {
                ResourceThreeBtn.Visibility = Visibility.Hidden;
                resourceThreeAmtTxt.Visibility = Visibility.Hidden;
                mssgTxt.Text = $"You've there aren't any {MainWindow.resources[3].Name} left to collect.";
            }
        }    

        private void OrganismImg_MouseDown(object sender, MouseButtonEventArgs e)
        {
            mssgTxt.Text = $"{MainWindow.organisms[3].PrintOrganismInfo(MainWindow.organisms[3].Name)}";
        }

        private void MutualObligateOrganismImg_MouseDown(object sender, MouseButtonEventArgs e)
        {
            HiddenResouceBtn.Visibility = Visibility.Visible;
            HiddenResourceAmtTxt.Visibility = Visibility.Visible;
            mssgTxt.Text = $"{MainWindow.organisms[14].PrintOrganismInfo(MainWindow.organisms[14].Name)}";
        }

        private void HiddenResouceBtn_Click(object sender, RoutedEventArgs e)
        {
            // Collect resource
            MainWindow.resources[10].ResourceAmount--;
            //MainWindow.resources[10].Quantity++;
            MainWindow.resources[10].AddQuantity(MainWindow.resources[10].Name);
            HiddenResourceAmtTxt.Text = $"{MainWindow.resources[10].ResourceAmount}";
            mssgTxt.Text = MainWindow.resources[10].PrintResourceInfo(MainWindow.resources[10].Name);
            if (MainWindow.resources[10].ResourceAmount == 0)
            {
                HiddenResouceBtn.Visibility = Visibility.Hidden;
                HiddenResourceAmtTxt.Visibility = Visibility.Hidden;
                mssgTxt.Text = $"You've there aren't any {MainWindow.resources[10].Name} left to collect.";
            }
        }

        private void CurrentEnvironmentTxt_MouseDown(object sender, MouseButtonEventArgs e)
        {
            mssgTxt.Text = MainWindow.currentEnvironment.PrintEnvironmentInfo(MainWindow.currentEnvironment.Name);
        }
    }
}
