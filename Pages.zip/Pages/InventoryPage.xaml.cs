﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VirtualEcosystemTwo.Pages
{
    /// <summary>
    /// Interaction logic for InventoryPage.xaml
    /// </summary>
    public partial class InventoryPage : Page
    {
        public InventoryPage()
        {
            InitializeComponent();
        }
        private void MapBtn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Pages/MapPage.xaml", UriKind.Relative));
        }
        private void CraftBtn_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new Uri("/Pages/CraftPage.xaml", UriKind.Relative));
        }
        private void BasaltRe_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/basalt.png", UriKind.Relative));
            infoTxt.Text = MainWindow.resources[4].PrintResourceInfo(MainWindow.resources[4].Name);

        }

        private void CrystalRe_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/crystal.png", UriKind.Relative));
            infoTxt.Text = MainWindow.resources[0].PrintResourceInfo(MainWindow.resources[0].Name);
        }

        private void HoneyRe_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/honey.png", UriKind.Relative));
            infoTxt.Text = MainWindow.resources[10].PrintResourceInfo(MainWindow.resources[10].Name);
        }

        private void LeadRe_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/lead.png", UriKind.Relative));
            infoTxt.Text = MainWindow.resources[2].PrintResourceInfo(MainWindow.resources[2].Name);
        }

        private void LimestoneRe_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/limestone.png", UriKind.Relative));
            infoTxt.Text = MainWindow.resources[5].PrintResourceInfo(MainWindow.resources[5].Name);
        }

        private void StalactitesRe_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/stalactites.png", UriKind.Relative));
            infoTxt.Text = MainWindow.resources[3].PrintResourceInfo(MainWindow.resources[3].Name);
        }

        private void StalagmitesRe_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/stalagmites.png", UriKind.Relative));
            infoTxt.Text = MainWindow.resources[1].PrintResourceInfo(MainWindow.resources[1].Name);

        }

        private void WildGrassRe_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/wildgrass.png", UriKind.Relative));
            infoTxt.Text = MainWindow.resources[8].PrintResourceInfo(MainWindow.resources[8].Name);
        }

        private void CoolWaterRe_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/coolwater.png", UriKind.Relative));
            infoTxt.Text = MainWindow.resources[9].PrintResourceInfo(MainWindow.resources[9].Name);
        }

        private void SilkRe_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ResourceImg/silk.png", UriKind.Relative));
            infoTxt.Text = MainWindow.resources[11].PrintResourceInfo(MainWindow.resources[11].Name);
        }

        private void Brick_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ItemImg/bricks.png", UriKind.Relative));
            infoTxt.Text = MainWindow.items[0].PrintItemInfo(MainWindow.items[0].Name);
        }

        private void Rope_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ItemImg/rope.png", UriKind.Relative));
            infoTxt.Text = MainWindow.items[3].PrintItemInfo(MainWindow.items[3].Name);

        }

        private void Ductape_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ItemImg/ductape.png", UriKind.Relative));
            infoTxt.Text = MainWindow.items[2].PrintItemInfo(MainWindow.items[2].Name);
        }

        private void PlasticBottle_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ItemImg/plasticBottle.png", UriKind.Relative));
            infoTxt.Text = MainWindow.items[1].PrintItemInfo(MainWindow.items[1].Name);

        }

        private void Cloth_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ItemImg/cloth.png", UriKind.Relative));
            infoTxt.Text = MainWindow.items[4].PrintItemInfo(MainWindow.items[4].Name);
        }

        private void HealingPotion_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ItemImg/healthPotion.png", UriKind.Relative));
            infoTxt.Text = MainWindow.items[5].PrintItemInfo(MainWindow.items[5].Name);
        }

        private void TempShelter_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ItemImg/shelter.png", UriKind.Relative));
            infoTxt.Text = MainWindow.items[6].PrintItemInfo(MainWindow.items[6].Name);
        }

        private void CoolingSuit_Selected(object sender, RoutedEventArgs e)
        {
            previewImg.Source = new BitmapImage(new Uri("/Graphics/ItemImg/suit.png", UriKind.Relative));
            infoTxt.Text = MainWindow.items[7].PrintItemInfo(MainWindow.items[7].Name);
        }


    }
}
