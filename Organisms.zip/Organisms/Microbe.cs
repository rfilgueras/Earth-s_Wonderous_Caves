﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VirtualEcosystemTwo.Organisms
{
    class Microbe : Organism
    {

    }
}
