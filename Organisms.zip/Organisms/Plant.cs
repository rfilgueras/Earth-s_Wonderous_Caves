﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VirtualEcosystemTwo.Organisms
{
    public class Plant : Organism
    {
        public bool IsPoisonous { get; set; }
        
    }
}
