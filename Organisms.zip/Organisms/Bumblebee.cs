﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Threading.Tasks;

namespace VirtualEcosystemTwo.Organisms
{
    class Bumblebee : Insect
    {
        public Bumblebee()
        {
            string path = "../../Info/Organisms.xml";
            ReadInfo.ReadOrganism(path);
            Name = "Crystal Bumblebee";
        }       

    }
}
