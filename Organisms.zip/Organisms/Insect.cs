﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VirtualEcosystemTwo.Organisms
{
    public class Insect : Organism
    {
        public bool CanFly { get; set; }
        public bool CanCrawl { get; set; }

    }
}